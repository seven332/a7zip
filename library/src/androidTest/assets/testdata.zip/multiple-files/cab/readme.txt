The test files was created with CabPack, a freeware compression program
(http://www.larshederer.homepage.t-online.de/cabpack.htm)

Method 0 - MSZIP
Method 1 - LZX (Compression memory 15)
Method 2 - LZX (Compression memory 21)
