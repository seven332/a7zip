The files
- archive1.zip.6.lzh
- archive1.zip.7.lzh
- archive3.zip.6.lzh
- archive3.zip.7.lzh
can't be extracted with p7zip 4.65