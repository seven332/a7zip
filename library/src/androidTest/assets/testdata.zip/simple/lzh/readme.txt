The files
- simple3.dat.6.lzh
- simple3.dat.7.lzh
can't be extracted with p7zip 4.65